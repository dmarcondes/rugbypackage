meantry <- function(){
  y<- sum(Game[,10])
  mean <- y/Players
  print(mean)
}