meanredcard <- function(){
  y<- sum(Game[,13])
  mean <- y/Players
  print(mean)
}