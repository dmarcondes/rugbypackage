meandropgoal <- function(){
  y<- sum(Game[,11])
  mean <- y/Players
  print(mean)
}