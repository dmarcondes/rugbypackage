total <- function(){
  total <- sum(Game[,14])
  print(total)
  
}