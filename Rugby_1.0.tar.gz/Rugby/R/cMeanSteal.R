meansteal <- function(){
  y<- sum(Game[,5])
  mean <- y/Players
  print(mean)
}