meanwrongpass <- function(){
  y<- sum(Game[,6])
  mean <- y/Players
  print(mean)
}