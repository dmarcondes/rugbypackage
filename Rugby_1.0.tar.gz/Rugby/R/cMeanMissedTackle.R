meanmissedtackle <- function(){
  y<- sum(Game[,2])
  mean <- y/Players
  print(mean)
}