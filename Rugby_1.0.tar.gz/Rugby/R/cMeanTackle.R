meantackle <- function(){
  y<- sum(Game[,1])
  mean <- y/Players
  print(mean)
}