num15 <- function(){
  print("Type the name of the players: ")
  num15 <- c(scan("",what="character",nmax=23))
    
}