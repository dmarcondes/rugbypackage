meanpoint <- function(){
  y<- sum(Game[,14])
  mean <- y/Players
  print(mean)
}