meanconvertedpenalty <- function(){
  y<- sum(Game[,9])
  mean <- y/Players
  print(mean)
}