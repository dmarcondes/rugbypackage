meanrightpass <- function(){
  y<- sum(Game[,3])
  mean <- y/Players
  print(mean)
}