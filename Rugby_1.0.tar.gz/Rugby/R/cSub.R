subt <- function(){
  Players <- Players + 1 
  assign("Players",Players,.GlobalEnv)
}