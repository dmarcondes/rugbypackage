num7 <- function(){
  print("Type the name of the players: ")
  num7 <- c(scan("",what="character",nmax=12))
  
}