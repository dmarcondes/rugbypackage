meanyellowcard <- function(){
  y<- sum(Game[,12])
  mean <- y/Players
  print(mean)
}